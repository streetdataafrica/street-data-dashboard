import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix default icon issue with leaflet in some build environments
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const KPIS = [
  { label: 'Farmers Onboarded', value: 320 },
  { label: 'Farms Analyzed', value: 180 },
  { label: 'States Covered', value: 5 },
  { label: 'Soil Samples', value: 1200 },
];

const cropDistribution = [
  { name: 'Maize', value: 40 },
  { name: 'Cassava', value: 25 },
  { name: 'Yam', value: 20 },
  { name: 'Rice', value: 15 },
];
const COLORS = ['#2b8a3e', '#f59e0b', '#ef4444', '#06b6d4'];

const onboardingTrend = [
  { month: 'Jan', count: 40 },
  { month: 'Feb', count: 55 },
  { month: 'Mar', count: 62 },
  { month: 'Apr', count: 48 },
  { month: 'May', count: 75 },
  { month: 'Jun', count: 80 },
];

const yieldPerRegion = [
  { region: 'Ogun', yield: 2.8 },
  { region: 'Oyo', yield: 2.3 },
  { region: 'Ondo', yield: 2.6 },
  { region: 'Lagos', yield: 1.9 },
];

const farmers = [
  { name: 'Samuel O.', location: 'Abeokuta', crop: 'Maize', size: '2 ha', soil_pH: 6.2, recommendation: 'Reduce fertilizer by 12%' , lat:7.1561, lon:3.3484},
  { name: 'Daniel F.', location: 'Ibadan', crop: 'Yam', size: '3 ha', soil_pH: 5.8, recommendation: 'Improve drainage', lat:7.3775, lon:3.9470 },
  { name: 'Grace U.', location: 'Akure', crop: 'Cassava', size: '1.5 ha', soil_pH: 6.5, recommendation: 'No change', lat:7.2526, lon:5.1939 },
];

export default function App(){
  return (
    <div className="min-h-screen" style={{display:'flex'}}>
      <aside style={{width:260, background:'#000', color:'#fff', padding:24, minHeight:'100vh'}}>
        <div style={{display:'flex', alignItems:'center', gap:12, marginBottom:24}}>
          <img src="/logo.png" alt="Street Data" style={{width:48,height:48,objectFit:'contain'}} />
          <div style={{fontWeight:700, fontSize:20}}>Street Data</div>
        </div>
        <div style={{marginBottom:20}}>
          <div className="nav-item" style={{background:'rgba(255,255,255,0.04)'}}>Dashboard</div>
          <div className="nav-item">Farmer Records</div>
          <div className="nav-item">Soil Analysis</div>
          <div className="nav-item">Insights</div>
          <div className="nav-item">Reports</div>
        </div>
        <div style={{marginTop:40, fontSize:12, color:'#9ca3af'}}>Powered by Street Data | Innovating Africa's Green Future</div>
      </aside>
      <main style={{flex:1, padding:28}}>
        <header style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:24}}>
          <h1 style={{fontSize:22, fontWeight:700}}>Street Data Dashboard</h1>
          <div style={{display:'flex', alignItems:'center', gap:12}}>
            <input placeholder="Search" style={{padding:8,borderRadius:6,border:'1px solid #e5e7eb'}}/>
            <div style={{fontSize:13,color:'#4b5563'}}>Sept 7, 2022</div>
            <div style={{width:36,height:36,borderRadius:18,background:'#e5e7eb',display:'flex',alignItems:'center',justifyContent:'center'}}>U</div>
          </div>
        </header>

        <section style={{display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:18}}>
          {KPIS.map(k=>(
            <div key={k.label} className="bg-white rounded shadow-sm p-4">
              <div style={{fontSize:12,color:'#6b7280'}}>{k.label}</div>
              <div style={{fontSize:20,fontWeight:700}}>{k.value}</div>
            </div>
          ))}
        </section>

        <section style={{display:'grid', gridTemplateColumns:'2fr 1fr', gap:16}}>
          <div style={{display:'flex', flexDirection:'column', gap:16}}>
            <div className="bg-white rounded shadow-sm p-4">
              <h3 style={{fontWeight:700, marginBottom:8}}>Crop Distribution</h3>
              <div style={{height:260}}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={cropDistribution} dataKey="value" nameKey="name" outerRadius={80} innerRadius={30}>
                      {cropDistribution.map((entry, index) => <Cell key={index} fill={COLORS[index%COLORS.length]} />)}
                    </Pie>
                    <Legend verticalAlign="bottom" />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:16}}>
              <div className="bg-white rounded shadow-sm p-4">
                <h3 style={{fontWeight:700, marginBottom:8}}>Farmer Onboarding Trend</h3>
                <div style={{height:160}}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={onboardingTrend}>
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="count" fill="#f59e0b" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="bg-white rounded shadow-sm p-4">
                <h3 style={{fontWeight:700, marginBottom:8}}>Map — Sample Farm Clusters</h3>
                <div style={{height:160}}>
                  <MapContainer center={[7.3,4.0]} zoom={7} style={{height:'100%', borderRadius:6}}>
                    <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                    {farmers.map((f,idx)=>(
                      <Marker key={idx} position={[f.lat,f.lon]}>
                        <Popup><strong>{f.name}</strong><br/>{f.location}<br/>{f.crop}</Popup>
                      </Marker>
                    ))}
                  </MapContainer>
                </div>
              </div>
            </div>

            <div className="bg-white rounded shadow-sm p-4">
              <h3 style={{fontWeight:700, marginBottom:8}}>AI Insight</h3>
              <p style={{margin:0}}>Street Data AI recommends fertilizer reduction in Ogun by 12% based on soil pit analysis.</p>
            </div>
          </div>

          <div style={{display:'flex', flexDirection:'column', gap:16}}>
            <div className="bg-white rounded shadow-sm p-4">
              <h3 style={{fontWeight:700, marginBottom:8}}>Average Yield per Region (t/ha)</h3>
              <div style={{height:240}}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={yieldPerRegion} layout="vertical">
                    <XAxis type="number" />
                    <YAxis dataKey="region" type="category" />
                    <Tooltip />
                    <Bar dataKey="yield" fill="#2b8a3e" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white rounded shadow-sm p-4">
              <h3 style={{fontWeight:700, marginBottom:8}}>Recent Farmer Records</h3>
              <table className="table">
                <thead>
                  <tr style={{color:'#6b7280'}}>
                    <th>Name</th><th>Location</th><th>Crop</th><th>Farm Size</th>
                  </tr>
                </thead>
                <tbody>
                  {farmers.map((f,i)=>(
                    <tr key={i}>
                      <td>{f.name}</td><td>{f.location}</td><td>{f.crop}</td><td>{f.size}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="bg-white rounded shadow-sm p-4" style={{fontSize:12,color:'#6b7280'}}>
              <strong>Note:</strong> This is a prototype with dummy data for NASENI application. Replace data with your API or CSV upload to make it live.
            </div>
          </div>
        </section>

        <footer style={{marginTop:20,color:'#6b7280'}}>© {new Date().getFullYear()} Street Data</footer>
      </main>
    </div>
  );
}
